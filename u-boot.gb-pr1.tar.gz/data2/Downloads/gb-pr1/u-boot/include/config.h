#include <soc/soc_list.h>
#define CONFIG_BUILD_DATE_UTC			2017-10-25
#define CONFIG_ATHEROS				1
#define CONFIG_MACH_QCA953x			1
#define CONFIG_HOSTNAME				u-boot_GB_PR1
#define CONFIG_GPIO_RESET_BTN			12
#define CONFIG_GPIO_RESET_BTN_ACTIVE_LOW	1
#define CONFIG_MAX_UBOOT_SIZE			262144
#define CONFIG_MAX_UBOOT_SIZE_HEX		0x40000
#define SOC_TYPE				QCA_QCA953X_SOC
#define CONFIG_BOARD_CUSTOM_STRING		GB_PR1
#define CONFIG_DEFAULT_FLASH_SIZE_IN_MB		8
#define CONFIG_FOR_GB_PR1			1
#define CONFIG_USB				1
#define CFG_ATHRS27_PHY				1
#define CFG_ATH_GMAC_NMACS			2

/* Automatically generated - do not edit */
#include <configs/ap143.h>
