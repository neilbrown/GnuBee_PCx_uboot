/*
 * MediaTek/Ralink Wireless SOC common registers definitions
 *
 * Copyright (C) 2014 Piotr Dymacz <piotr@dymacz.pl>
 *
 * SPDX-License-Identifier:GPL-2.0
 */

#ifndef _MTK_SOC_COMMON_H_
#define _MTK_SOC_COMMON_H_

#include <soc/soc_common.h>

#endif /* _MTK_SOC_COMMON_H_ */
